<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Laravel\Sanctum\HasApiTokens;


class User extends Authenticatable
{

    /** @use HasFactory<UserFactory> */    
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // User has ONE profile
    public function profile(): HasOne
    {
        return $this->hasOne(Profile::class);
    }

    // User has MANY posts
    public function posts(): HasMany
    {
        return $this->hasMany(Post::class);
    }

    // User has MANY comments
    public function comments(): HasMany
    {
        return $this->hasMany(Comment::class);
    }


    // User → Comments through Posts
    public function allComments(): HasManyThrough
    {
        return $this->hasManyThrough(Comment::class, Post::class);
    }
}
